package com.example.andresrocherescriva;

import android.os.Bundle;
import android.preference.PreferenceFragment;

import androidx.appcompat.app.AppCompatActivity;

public class preferences extends AppCompatActivity {

    public static class settings extends PreferenceFragment{

    public void onCreate(Bundle savedInstanceTate) {
        super.onCreate(savedInstanceTate);
        addPreferencesFromResource(R.xml.preferences);
    }
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction().replace(android.R.id.content, new settings()).commit();
    }

}
