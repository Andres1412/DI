package com.example.andresrocherescriva;

import android.os.Bundle;
import android.preference.PreferenceFragment;

import androidx.appcompat.app.AppCompatActivity;

public class pedidos extends AppCompatActivity {

    public static class pedido extends PreferenceFragment {

        public void onCreate(Bundle savedInstanceTate) {
            super.onCreate(savedInstanceTate);
            addPreferencesFromResource(R.xml.activity_pedido);
        }
    }

    }



