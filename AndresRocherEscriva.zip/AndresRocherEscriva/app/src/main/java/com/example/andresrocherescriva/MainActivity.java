package com.example.andresrocherescriva;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showPopup(View v) {

        PopupMenu popMenu = new PopupMenu(this, v);
        popMenu.setOnMenuItemClickListener(this);
        popMenu.inflate(R.menu.main);
        popMenu.show();
    }

    public void ShowToast(View v) {

        Toast.makeText(this, "Esta opción esta deshabilitada", Toast.LENGTH_SHORT).show();

    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.Hola:
                Toast.makeText(this, "Hola, buenos días", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.Adios:
                Toast.makeText(this, "Adiós, grácias por entrar", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu optionsMenu) {

        getMenuInflater().inflate(R.menu.optionmenu, optionsMenu);
        return true;
    }

    public boolean onOptionItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {

            case R.id.Pedido:
                Intent intent = new Intent(this, pedidos.class);
                MainActivity.this.startActivity(intent);
                MainActivity.this.finish();

            case R.id.Info:
                Toast.makeText(this, "La información no esta disponible ahora", Toast.LENGTH_SHORT).show();

            case R.id.Fav:
                Toast.makeText(this, "Favoritos", Toast.LENGTH_SHORT).show();

            case R.id.Ajustes:
                Intent intent1 = new Intent(this, preferences.class);
                MainActivity.this.startActivity(intent1);
                MainActivity.this.finish();

            case R.id.Cont:
                Toast.makeText(this, "Forma de contacto", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(menuItem);
    }


}